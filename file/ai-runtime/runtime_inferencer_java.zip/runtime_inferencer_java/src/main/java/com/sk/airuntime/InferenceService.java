package com.sk.airuntime;

import com.sk.airuntime.utils.JsonParser;
import com.sk.airuntime.utils.SecurityUtil;
import com.sk.airuntime.vo.ApiTokenInfo;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.conn.ssl.NoopHostnameVerifier;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.Map;

import javax.net.ssl.SSLContext;

public class InferenceService {

    private String baseEndpoint = "https://aiip.skcc.com";
    private long tokenValidMinutes = 10;
    private PublicKey apiPublicKey;
    private String apiKeyId;
    private ApiTokenInfo tokenInfo;

    public InferenceService(String apikeyId,
                            String encodePublicKey )
            throws GeneralSecurityException {
        this.apiKeyId = apikeyId;
        this.apiPublicKey = SecurityUtil.getPublicKeyFromBase64Encrypted(encodePublicKey);
    }

    public InferenceService(String baseEndpoint,
                            String apikeyId,
                            String encodePublicKey )
            throws GeneralSecurityException {
        this(apikeyId, encodePublicKey);
        this.baseEndpoint = baseEndpoint;
    }

    private  String getKeyAuthEndpoint(){
        return baseEndpoint + "/api/common/backend/admin/api/keyauth";
    }

    private String getPredictEndpoint(){
        return baseEndpoint + "/api/runtime/ifservice/predict";
    }

    private String getPredictWithFileEndpoint(){
        return baseEndpoint + "/api/runtime/ifservice/infer";
    }

    private CloseableHttpClient buildClient() throws GeneralSecurityException {
        // Create a custom SSLContext that bypasses certificate verification
        SSLContext sslContext = SSLContextBuilder.create()
                .loadTrustMaterial((chain, authType) -> true)
                .build();

        HttpClientBuilder clientBuilder = HttpClientBuilder.create()
                .setSslcontext(sslContext)
                .setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE);
        return clientBuilder.build();
    }

    private HttpUriRequest createRequestPost(String url, String jsonBody) {
        HttpPost request = new HttpPost(url);
        request.setHeader(HttpHeaders.CONTENT_TYPE, "application/json");
        request.setEntity(new StringEntity(jsonBody, StandardCharsets.UTF_8));
        return request;
    }

    private HttpUriRequest createRequestPost(String url, String token, String jsonBody) {
        HttpPost request = new HttpPost(url);
        request.setHeader(HttpHeaders.CONTENT_TYPE, "application/json");
        request.setHeader("Api-Auth-Token", token);
        request.setEntity(new StringEntity(jsonBody, StandardCharsets.UTF_8));

        return request;
    }

    private HttpUriRequest createMultipartRequestPost(String url, String token, File fileData) {
        HttpPost request = new HttpPost(url);
        request.setHeader("Api-Auth-Token", token);

        // Create a multipart entity builder
        MultipartEntityBuilder builder = MultipartEntityBuilder.create();
        // Add a file part
        builder.addBinaryBody("instances", fileData);
        // Build the multipart entity
        HttpEntity multipartEntity = builder.build();

        // Set the entity on the request
        request.setEntity(multipartEntity);

        return request;
    }

    private HttpUriRequest createMultipartRequestPost(String url, String token, InputStream fileData) {
        HttpPost request = new HttpPost(url);
        request.setHeader("Api-Auth-Token", token);

        // Create a multipart entity builder
        MultipartEntityBuilder builder = MultipartEntityBuilder.create();
        // Add a file part
        builder.addBinaryBody("instances", fileData, ContentType.APPLICATION_OCTET_STREAM, "instances");
        // Build the multipart entity
        HttpEntity multipartEntity = builder.build();

        // Set the entity on the request
        request.setEntity(multipartEntity);

        return request;
    }

    private long getCurrentTime(){
        return System.currentTimeMillis()/1000;
    }

    private void acquireNewToken() throws GeneralSecurityException, IOException {

        long currentTime = getCurrentTime();
        String encryptMsg = SecurityUtil.encryptRSA(String.valueOf(currentTime), apiPublicKey);

        var requestData = Map.of(
                "keyId", apiKeyId,
                "encMessage", encryptMsg,
                "duration" , tokenValidMinutes);

        JsonParser jsonParser =  new JsonParser();
        CloseableHttpResponse response;

        response = buildClient().execute(createRequestPost(this.getKeyAuthEndpoint(), jsonParser.mapToJsonStr(requestData)));
        Map<String, Object> responseData = jsonParser.parse(EntityUtils.toString(response.getEntity()));

        if (response.getStatusLine().getStatusCode() != 200){
            this.tokenInfo = null;
            throw new RuntimeException(String.format("Fail to get authToken (resp status code:%d)"
                    , response.getStatusLine().getStatusCode()));
        }

        this.tokenInfo = new ApiTokenInfo((String) responseData.get("result"), currentTime, tokenValidMinutes);
    }

    public String predict(String modelId, String data) throws IOException, GeneralSecurityException {

        if(tokenInfo == null || !tokenInfo.valid()){  acquireNewToken(); }

        var endpoint = this.getPredictEndpoint() + '/' + modelId;
        HttpUriRequest request = createRequestPost(endpoint, tokenInfo.getToken(), data);

        var response = buildClient().execute(request);

        if (response.getStatusLine().getStatusCode() != 200){
            this.tokenInfo = null;
            throw new RuntimeException(String.format("Fail to predict (resp status code:%d)"
                    , response.getStatusLine().getStatusCode()));
        }
        return EntityUtils.toString(response.getEntity(),"UTF-8");
    }

    public String predictWithFile(String modelId, File data) throws IOException, GeneralSecurityException {

        if(tokenInfo == null || !tokenInfo.valid()){  acquireNewToken(); }

        var endpoint = this.getPredictWithFileEndpoint() + '/' + modelId;
        HttpUriRequest request = createMultipartRequestPost(endpoint, tokenInfo.getToken(), data);

        var response = buildClient().execute(request);

        if (response.getStatusLine().getStatusCode() != 200){
            this.tokenInfo = null;
            throw new RuntimeException(String.format("Fail to predict (resp status code:%d)"
                    , response.getStatusLine().getStatusCode()));
        }
        return EntityUtils.toString(response.getEntity(),"UTF-8");
    }

    public String predictWithInputStream(String modelId, InputStream data) throws IOException, GeneralSecurityException {

        if(tokenInfo == null || !tokenInfo.valid()){  acquireNewToken(); }

        var endpoint = this.getPredictWithFileEndpoint() + '/' + modelId;
        HttpUriRequest request = createMultipartRequestPost(endpoint, tokenInfo.getToken(), data);

        var response = buildClient().execute(request);

        if (response.getStatusLine().getStatusCode() != 200){
            this.tokenInfo = null;
            throw new RuntimeException(String.format("Fail to predict (resp status code:%d)"
                    , response.getStatusLine().getStatusCode()));
        }
        return EntityUtils.toString(response.getEntity(),"UTF-8");
    }

}
