import com.sk.airuntime.InferenceService;

import java.io.File;

public class TabularModelInferenceTest {

    public static void main(String[] args) {

//        String apikeyId = "{input your apikeyId}";
//        String apikey = "{input your apikey}";
//        String endpoint = "{input your endpoint}";

        //example
        String baseEndpoint = "https://aiip.accuinsight.io";
        String apikeyId = "BDF8BB3B566E";
        String apikey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA6QJ/sIwjg4zrbZXLYHcrBgcDjKy1whkJ5fXGPizDskg+EoMo4tfyWKYMxhXukgpb0CXY+WVieGTcy6jitETPDTU51jEdePGPrDJRbcDLGDyKSRqKQPYn1EhB0Zij7aCnDtSPFTpWKVrb+FEYOT9UcLIwYoGCvE0jOJJiDhNv7BS3brkKWO9mXJIHNU+Oog6k+5k4M0bfjKlRA/2MPvKlaFWyjGICsml2tAPDWc7ivFHR+qMcmysGMAICtDk6cem62rvqF4YpcJNSOxNyUJ2YOAtWCh0u1xp/zs52NPSrV02I8jQeiLkPaUuURdU0NAzrmVvylmoUWyNmS7ApqQOF1wIDAQAB";

        String modelId =  "mdl-9cf2a377-72d1-4086-9b01-40db4ace6152";

        //example data
        String data = "{" +
                "\"instances\": [" +
                "[4.7, 3.2, 1.3, 0.2]," +
                "[4.6, 3.1, 1.5, 0.2]" +
                "]," +
                "\"labels\"  : [ \"sepal_length\", \"sepal_width\", \"petal_length\", \"petal_width\" ]" +
                "}";

        try {

            InferenceService infService = new InferenceService(baseEndpoint, apikeyId, apikey);

            String output = infService.predict(modelId, data);

            System.out.println(output);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
