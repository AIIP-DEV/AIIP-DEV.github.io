import com.sk.airuntime.InferenceService;

import java.io.File;
import java.io.InputStream;

public class ImageModelInferenceTest {

    public static void main(String[] args) {

//        String apikeyId = "{input your apikeyId}";
//        String apikey = "{input your apikey}";
//        String endpoint = "{input your endpoint}";

        //example
        String baseEndpoint = "https://aiip-dev.skcc.com";
        String apikeyId = "8D0FD08E89E7";
        String apikey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA2OmRh8Yry23MZu5nG1VE7DvQh+kAuoCoqtbtvOB5nEE9HaN7H" +
                "YTA5awRpQHkkd2+yz8gWHEl0mbp5O60kkfqw4QR3i+w7KkMtp65LZH/GAfzJBNYH+Oj3XW9hU1417LeEIDxUCDtReoOkvssntawp" +
                "/eZMPNCojiPdtExfLke6EA1/cJn0YzfPWpfxMlRs0jP+cUE0oTSTfhCRSTl1mWV2NHO2+MQ8NXEFVKxONSepP27PYyvDiGegwBhR" +
                "lFdG4kDvkPTsEFoghgqpqeUEtAC9MNGKUB6BXaP7Yi4vc7GerjONdDHQk1jPAbZuMSCaJ7pjzhvtSpc3Ts2+DiOefdXxwIDAQAB";

        String modelId =  "mdl-6a517aa4-1fbb-42dc-ba58-1161fcc7c257";

        // Load input file from the resources folder
        ClassLoader classLoader = ImageModelInferenceTest.class.getClassLoader();
        String filePath = "images/input.png";

        // In case of using File as Input
        File inputFile = new File(classLoader.getResource(filePath).getFile());

        // In case of using InputStream as Input
        //InputStream inputStream = classLoader.getResourceAsStream(filePath);

        try {

            InferenceService infService = new InferenceService(baseEndpoint, apikeyId, apikey);

            // In case of using File, use the following code
            String output = infService.predictWithFile(modelId, inputFile);

            // In case of using InputStream, use the following code
            // String output = infService.predictWithInputStream(modelId, inputStream);

            System.out.println(output);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
