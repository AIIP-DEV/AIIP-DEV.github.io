# runtime_inferencer_java

## Inferencer Example for Tabular Model
```
test/java/TabularModelInferenceTest.java
```

## Inferencer Example for Image Model
```
test/java/ImageModelInferenceTest.java
```
