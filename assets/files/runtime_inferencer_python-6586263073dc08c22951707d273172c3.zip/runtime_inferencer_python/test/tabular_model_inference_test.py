from src.inference_service import AIRuntime

# apiKeyId = "{input your apiKeyId}"
# apiKey = "{input your apiKey}"
# modelId = "{input your modelId}"

# example
endPoint = "https://aiip.skcc.com"
apiKeyId = "ED23A3B575C2"
apiKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAnYpPCa3MwqLj55DSrxCswp3rUgcMTuKFMCc76YtMjHB7h44r330had" \
         "lHehCqIp9uUKGjg6f4u0pUTinK8CCB75/lrC94PPV0AgFHog3EX0BRfvI1GovIdhaJzJvqsAB9VKMRa9YJUbmNXfDddKfcFLu8" \
         "7xgtVsF9linxeihchbUicFgOS3wOP26OyrHTXybYYLp5KjkegvFzF9LmI4ZBkyoNVJcr2Mm6lxqqEnOPdIawuPTToetzxEDJE9" \
         "RrOmE5LPmJcgWIkMOC+v/ptZnnx/YkXj236e6NNGk+DeK1/i5gojpZ1x5IXiyaWhKb5uwgY1cXSBCdTENnl9ONqhh33QIDAQAB"

modelId = "mdl-58aa2b86-d268-4c2b-889c-6eac2472abf5"

data = {
    "instances": [
        [5.1, 3.5, 1.4, 0.2],
        [4.6, 3.1, 1.5, 0.2]
    ],
    "labels": ["sepal_length", "sepal_width", "petal_length", "petal_width"]
}

try:
    ai_runtime: AIRuntime = AIRuntime(end_point=endPoint, access_key_id=apiKeyId, access_key=apiKey, model_id=modelId)

    predict_result = ai_runtime.predict(modelId, data)
    print(predict_result)

except Exception as e:
    print(e)
