# runtime_inferencer_python

## Inferencer Example for Tabular Model
```
test/tabular_model_inference_test.py
```

## Inferencer Example for Image Model
```
test/image_model_inference_test.py
```
